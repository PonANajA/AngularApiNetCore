import { Component } from '@angular/core';
import { AppService } from '../app.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrl: './test.component.css'
})
export class TestComponent {
  constructor(private appService: AppService,private http: HttpClient){}

  textApiOCR:any
  pathApi:string | null = null

  hello():any {
    console.log(this.appService.test())
  }

  async testfile(event: any) {
    const files = event.target.files[0]
    console.log(files)


    const reader = new FileReader();
    reader.readAsDataURL(files);
    reader.onload = ((e) => {
      const file = e.target as FileReader;
      if(null!=file){
        let base64 = file.result?.toString();
        console.log("baSE : ",base64);
        
      }else{
        console.log("NULLLLLLLL");
      }
      
      
    });



    // const reader = new FileReader();
    // reader.onload = (e: any) => {
    //   this.pathApi = e.target.result as string
    // }
    // reader.readAsDataURL(file)
    const data = {
      pathFile: files.name
    }
    this.http.post("http://localhost:5196/api/AngularApi/GetNotes", data).subscribe({
      next: (res) => {
        this.textApiOCR = res
        console.log(res)
      } ,
      error: (err) => {
        console.log(err)
        console.log(files)
      },
      complete: () => {
        console.log("Success")
      }
    })
  }

  testapi() {
    this.http.get("http://localhost:5196/api/AngularApi/GetNotes",{}).subscribe({
      next: (res) => {
        this.textApiOCR = res
        console.log(res)
      } ,
      error: (err) => {
        console.log(err)
      },
      complete: () => {
        console.log("Success")
      }
    })
  }
}
