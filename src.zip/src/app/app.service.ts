import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AppService {

  constructor(private http:HttpClient){
  }

  name:string = ""
  
  test(): any {
    console.log(this.name)
  }
  readonly APIUrl="http://localhost:5196/api/AngularApi/";

  GetNotes(){
    var newNotes = this.test.name
    var formData=new FormData();
    formData.append("newNotes",newNotes);
    this.http.post(this.APIUrl+'GetNotes',formData).subscribe(data=>{
      alert(data);
    })
  }
}
