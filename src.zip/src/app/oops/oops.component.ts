import { Component } from '@angular/core';

@Component({
  selector: 'app-oops',
  templateUrl: './oops.component.html',
  styleUrl: './oops.component.css'
})
export class OopsComponent {

}
