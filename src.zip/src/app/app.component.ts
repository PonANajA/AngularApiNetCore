import { Component } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'angularApiNetCore';
  readonly APIUrl="http://localhost:5196/api/AngularApi/";

  constructor(private http:HttpClient){
  }

}
